import React from 'react';

export default class Child extends React.Component{
    state = {
        value :''
    }
    handleChange = e =>{
        debugger
        this.setState({value:e.target.value})
        this.props.getData(e.target.value);
    }
    render(){
        return (
            <input 
                value = {this.state.value}
                onChange = {this.handleChange}
                placeholder="type something here ..."/>
        )
    }
}