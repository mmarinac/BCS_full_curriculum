import React from 'react';

export default class Child2 extends React.Component{
    render(){
        debugger
        return(
            <h1>I am the second Child {this.props.data}</h1>
        )
    }
}