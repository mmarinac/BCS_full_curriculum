import React from 'react';
import Child from './Child'
import Child2 from './Child2';
class App extends React.Component {
  state = {
    data:''
  }
  getData = myArgument => {
    debugger
    this.setState({data:myArgument})
  } 
  render() {
    return (
      <div>
        <Child
          getData = {this.getData}
        />
        <Child2
          data = {this.state.data}
        />
      </div>

    );
  }
}

export default App;
