// =============== require and run express in a single line
const app =require('express')();
// =============== add body parser ===============
const bodyParser= require('body-parser');
const mongoose = require('mongoose');
const port = process.env.port || 3000;
// =============== BODY PARSER SETTINGS =====================
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
// =============== DATABASE CONNECTION =====================
async function connecting(){
try {
    await mongoose.connect('mongodb://127.0.0.1/newdatabase', { useUnifiedTopology: true , useNewUrlParser: true })
    console.log('Connected to the DB')
} catch ( error ) {
    console.log('ERROR: Seems like your DB is not running, please start it up !!!');
}
}
connecting()
mongoose.set('useCreateIndex', true);
// =============== ROUTES ==============================
const todosRoute = require('./routes/todos');
const usersRoute = require('./routes/users');
// =============== USE ROUTES ==============================
app.use('/todos', todosRoute);
app.use('/users', usersRoute);
// =============== START SERVER =====================
app.listen(port, () => 
    console.log(`server listening on port ${port}`
));