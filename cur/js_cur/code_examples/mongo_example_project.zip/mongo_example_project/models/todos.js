const mongoose = require('mongoose');

const todoSchema = new mongoose.Schema({
    todo:{ type:String, required:true, unique:true },
    userID:{type:mongoose.Types.ObjectId, ref:'User'}
});
const Todos = mongoose.model('todos', todoSchema );
module.exports = Todos;