const router = require('express').Router();
const controller = require('../controllers/users')
// ============= Create New users =============
router.post('/new', controller.create);

module.exports  = router;