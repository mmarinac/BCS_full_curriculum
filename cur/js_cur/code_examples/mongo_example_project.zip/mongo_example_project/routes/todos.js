const router =  require('express').Router();
const controller = require('../controllers/todos');
// =============== FIND ALL TODOS ===============
router.get('/',controller.find);
// =============== FIND ALL TODOS BY USER ID===============
router.get('/todos_by_user_id/:userID',controller.findTodosByUserId)
// =============== ADD TODO TO DB ===============
router.post('/new',controller.create);
// =============== FIND ONE TODO BY ID ===============
router.get('/:id',controller.findOne);
// =============== REMOVE ONE TODO BY ID ===============
router.post('/todos/delete',controller.delete);
// =============== UPDATE ONE TODO BY ID ===============
router.post('/todos/update',controller.update);

module.exports =  router;