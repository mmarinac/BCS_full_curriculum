const Users = require('../models/users');
class UsersController {
    async create (req, res){
        let { username } = req.body;
        try{
            const newUser = await Users.create({ username });
            res.send({newUser});
        }
        catch(error){
            res.send({error});
        }
    };
};
module.exports =  new UsersController();