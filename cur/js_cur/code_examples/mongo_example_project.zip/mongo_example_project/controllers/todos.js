const Todos = require('../models/todos');

class TodosController {
    async find (req, res){
        try{
            const myTodos = await Todos.find({});
            res.send({myTodos});
        }
        catch(error){
            res.send({error});
        };
    }
    async findTodosByUserId(req, res){
        let { userID } = req.params;
        try{
            const myTodos = await Todos.find({ userID:userID });
            res.send({myTodos});
        }
        catch(error){
            res.send({error});
        }
    };
    async findOne (req, res){
        let { id } = req.params;
        try{
            const myTodo = await Todos.findOne({ _id:id });
            res.send({myTodo});
        }
        catch(error){
            res.send({error});
        };
    }
    async create (req, res){
        let{ todo, userID } = req.body;
        try{
            const newTodo = await Todos.create({
                todo:todo,
                userID: userID
            });
            res.send({newTodo})
        }
        catch(error){
            console.log(error);
            res.send({error})
        }
    }
    async delete (req, res){
        console.log('delete!!!')
        let { todo } = req.body;
        try{
            const removed = await Todos.deleteOne({ todo });
            res.send({removed});
        }
        catch(error){
            res.send({error});
        };
    }
async update (req, res){
        let { todo, newTodo } = req.body;
        try{
            const updated = await Todos.updateOne(
                { todo },{ todo:newTodo }
             );
            res.send({updated});
        }
        catch(error){
            res.send({error});
        };
    }


};
module.exports = new TodosController();