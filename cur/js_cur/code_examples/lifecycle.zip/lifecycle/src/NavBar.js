import React from 'react';

export default class Navbar extends React.Component{
    render(){
        return(
            <ul 
                style={{
                    display:'flex', 
                    justifyContent: 'space-around',
                    background:'black',
                    color:'white'
                }}>
                {['Home', 'About'].map((page)=>{
                    return <li onClick={
                        ()=> this.props.handleChangePage(page)}>{page}</li>
                })}
            </ul>
        )
    }
}