import React from 'react';

export default class AboutPage extends React.Component{
    render(){
        return(
            <h1>About page!</h1>
        )
    }
}