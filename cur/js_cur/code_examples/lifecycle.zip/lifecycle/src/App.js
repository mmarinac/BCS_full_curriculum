import React, { Component } from 'react';
import Home from './ChilOne';
import AboutPage from './AboutPage';
import Navbar from './NavBar'
class App extends Component {
  state = {
    page:'Home'
  }
  handleChangePage = page =>{
    this.setState({page:page})
  }
  render() {
    var currentPage;
    var { page } = this.state;
    if(page === 'Home'){
      currentPage =  <Home/>
    } if(page === 'About'){
      currentPage = <AboutPage/>
    }
    // {page === 'Home'? <Home/> : <AboutPage/> }
    return (
      <div>
        <Navbar 
          handleChangePage ={this.handleChangePage}
        />
       {currentPage }
      </div>
    );
  }
}

export default App;
